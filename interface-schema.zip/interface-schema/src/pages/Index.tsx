import { SchemaBuilder } from '@/components/SchemaBuilder';

const Index = () => {
  return <SchemaBuilder />;
};

export default Index;
